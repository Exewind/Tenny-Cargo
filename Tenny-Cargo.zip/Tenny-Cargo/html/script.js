let isWorking = false;
let currentDelivery = null;
let paymentPerDelivery = 500; // Varsayılan değer
let playerStats = {
    totalDeliveries: 0,
    totalEarnings: 0,
    lastDelivery: null
};

// DOM elementleri
const statusIndicator = document.getElementById('statusIndicator');
const statusText = document.querySelector('.status-text');
const startJobBtn = document.getElementById('startJobBtn');
const endJobBtn = document.getElementById('endJobBtn');
const closeBtn = document.getElementById('closeBtn');
const deliveryMenu = document.getElementById('deliveryMenu');
const deliverBtn = document.getElementById('deliverBtn');
// Cancel button removed

// Event listeners
startJobBtn.addEventListener('click', startJob);
endJobBtn.addEventListener('click', endJob);
closeBtn.addEventListener('click', closeMenu);
deliverBtn.addEventListener('click', deliverPackage);
// Cancel button removed

// NUI mesajları
window.addEventListener('message', function(event) {
    const data = event.data;
    // console.log("[Tenny-Cargo] NUI mesajı alındı:", data.type, data);
    
    switch(data.type) {
        case 'openMenu':
            // console.log("[Tenny-Cargo] openMenu mesajı işleniyor...");
            openMenu(data.data);
            break;
        case 'updateStatus':
            updateStatus(data.data);
            break;
        case 'updateDelivery':
            updateDelivery(data.data);
            break;
        case 'updateStats':
            updateStats(data.data);
            break;
        case 'openDeliveryMenu':
            // console.log("[Tenny-Cargo] openDeliveryMenu mesajı işleniyor...");
            openDeliveryMenu(data.data);
            break;
        case 'closeDeliveryMenu':
            closeDeliveryMenu();
            break;
        case 'closeMenu':
            closeMenu();
            break;
    }
});

function openMenu(data) {
    // Önce tüm menüleri kapat
    document.getElementById('cargo-menu').style.display = 'none';
    document.getElementById('deliveryMenu').style.display = 'none';
    
    // Config'den ödeme değerini al
    if (data.paymentPerDelivery) {
        paymentPerDelivery = data.paymentPerDelivery;
    }
    
    // Etiketleri uygula (lokalizasyon)
    if (data.labels) {
        // labels'ı global sakla
        window.lastLabels = data.labels;
        if (data.labels.title) document.getElementById('titleText').textContent = data.labels.title;
        if (data.labels.subtitle) document.getElementById('subtitleText').textContent = data.labels.subtitle;
        if (data.labels.start_job) document.getElementById('startJobText').textContent = data.labels.start_job;
        if (data.labels.end_job) document.getElementById('endJobText').textContent = data.labels.end_job;
        if (data.labels.close) document.getElementById('closeBtn').textContent = data.labels.close;
        // status text dinamik olarak updateUI içinde set edilecek
    }

    // Menüyü hemen göster
    document.getElementById('cargo-menu').style.display = 'block';
    isWorking = data.isWorking || false;
    updateUI();
}

function startJob() {
    fetch(`https://${GetParentResourceName()}/startJob`, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({})
    });
    
    isWorking = true;
    updateUI();
}

function endJob() {
    // Menüyü kapat
    document.getElementById('cargo-menu').style.display = 'none';
    
    // Server'a iş bitirme mesajı gönder
    fetch(`https://${GetParentResourceName()}/endJob`, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({})
    });
    
    // NUI focus'u kapat
    fetch(`https://${GetParentResourceName()}/closeMenu`, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({})
    });
    
    isWorking = false;
    currentDelivery = null;
    updateUI();
}


function closeMenu() {
    document.getElementById('cargo-menu').style.display = 'none';
    document.getElementById('deliveryMenu').style.display = 'none';
    fetch(`https://${GetParentResourceName()}/closeMenu`, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({})
    });
}

function openDeliveryMenu(data) {
    document.getElementById('deliveryMenu').style.display = 'block';
    
    // Labels
    if (data.labels) {
        if (data.labels.delivery_title) {
            const titleEl = document.getElementById('deliveryTitle');
            if (titleEl) titleEl.textContent = data.labels.delivery_title;
        }
        if (data.labels.deliver) {
            const deliverEl = document.getElementById('deliverText');
            if (deliverEl) deliverEl.textContent = data.labels.deliver;
        }
    }
    
    // NPC diyaloğunu göster
    const npcDialogueElement = document.getElementById('npcDialogue');
    if (npcDialogueElement && data.npcDialogue) {
        npcDialogueElement.textContent = data.npcDialogue;
    }
}

function closeDeliveryMenu() {
    document.getElementById('deliveryMenu').style.display = 'none';
}

function deliverPackage() {
    // Önce menüyü kapat
    closeDeliveryMenu();
    
    // Server'a teslimat mesajı gönder
    fetch(`https://${GetParentResourceName()}/deliverPackage`, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({})
    });
    
    // İstatistikleri güncelle
    playerStats.totalDeliveries++;
    playerStats.totalEarnings += paymentPerDelivery; // Config'den gelen değer
    playerStats.lastDelivery = new Date().toLocaleTimeString();
    
    // İstatistikler güncellendi (HTML elementleri mevcut değil)
    
    // Ana menüyü de kapat ve NUI focus'u kapat
    document.getElementById('cargo-menu').style.display = 'none';
    
    // NUI focus'u kapat
    fetch(`https://${GetParentResourceName()}/closeMenu`, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({})
    });
    
}

// cancelDelivery removed

function updateStatus(data) {
    isWorking = data.isWorking;
    updateUI();
}

function updateDelivery(data) {
    currentDelivery = data;
    updateDeliveryInfo();
}

function updateStats(data) {
    playerStats = data;
    updateStatsDisplay();
}

function updateUI() {
    if (isWorking) {
        statusText.textContent = (window.lastLabels && window.lastLabels.status_active) || 'İş Durumu: Aktif';
        startJobBtn.disabled = true;
        endJobBtn.disabled = false;
    } else {
        statusText.textContent = (window.lastLabels && window.lastLabels.status_ready) || 'İş Durumu: Hazır';
        startJobBtn.disabled = false;
        endJobBtn.disabled = true;
    }
}

function updateDeliveryInfo() {
    // Teslimat bilgileri güncellendi (HTML elementleri mevcut değil)
}


function showNotification(message, type) {
    // Basit bildirim sistemi
    const notification = document.createElement('div');
    notification.className = `notification ${type}`;
    notification.textContent = message;
    notification.style.cssText = `
        position: fixed;
        top: 20px;
        right: 20px;
        background: ${type === 'success' ? '#00ff88' : type === 'error' ? '#ff4444' : '#ffaa00'};
        color: ${type === 'success' ? '#000000' : '#ffffff'};
        padding: 15px 20px;
        border-radius: 8px;
        font-weight: bold;
        z-index: 1001;
        animation: slideInRight 0.3s ease-out;
    `;
    
    document.body.appendChild(notification);
    
    setTimeout(() => {
        notification.style.animation = 'slideOutRight 0.3s ease-in';
        setTimeout(() => {
            document.body.removeChild(notification);
        }, 300);
    }, 3000);
}

// CSS animasyonları
const style = document.createElement('style');
style.textContent = `
    @keyframes slideInRight {
        from {
            transform: translateX(100%);
            opacity: 0;
        }
        to {
            transform: translateX(0);
            opacity: 1;
        }
    }
    
    @keyframes slideOutRight {
        from {
            transform: translateX(0);
            opacity: 1;
        }
        to {
            transform: translateX(100%);
            opacity: 0;
        }
    }
`;
document.head.appendChild(style);

// Klavye kısayolları
document.addEventListener('keydown', function(event) {
    if (event.key === 'Escape') {
        closeMenu();
    }
});

// Sayfa yüklendiğinde
document.addEventListener('DOMContentLoaded', function() {
    // Menüyü gizle
    document.getElementById('cargo-menu').style.display = 'none';
    updateUI();
});
