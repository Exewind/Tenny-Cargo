let isWorking = false;
let tcDebug = false; // NUI debug kontrolü
let currentDelivery = null;
let paymentPerDelivery = 500; // Varsayılan değer
let playerStats = {
    totalDeliveries: 0,
    totalEarnings: 0,
    lastDelivery: null
};

// DOM elementleri
const statusIndicator = document.getElementById('statusIndicator');
const statusText = document.querySelector('.status-text');
const startJobBtn = document.getElementById('startJobBtn');
const endJobBtn = document.getElementById('endJobBtn');
const closeBtn = document.getElementById('closeBtn');
const deliveryMenu = document.getElementById('deliveryMenu');
const deliverBtn = document.getElementById('deliverBtn');
// Cancel button removed

// Event listeners
startJobBtn.addEventListener('click', startJob);
endJobBtn.addEventListener('click', endJob);
closeBtn.addEventListener('click', closeMenu);
deliverBtn.addEventListener('click', deliverPackage);
// Cancel button removed

// NUI mesajları
window.addEventListener('message', function(event) {
    const data = event.data;
    if (typeof data?.debug === 'boolean') tcDebug = data.debug;
    if (tcDebug) console.log("[Tenny-Cargo] NUI mesajı alındı:", data.type, data);
    
    switch(data.type) {
        case 'openMenu':
            if (tcDebug) console.log("[Tenny-Cargo] openMenu mesajı işleniyor...");
            openMenu(data.data);
            break;
        case 'updateStatus':
            updateStatus(data.data);
            break;
        case 'updateDelivery':
            updateDelivery(data.data);
            break;
        case 'updateStats':
            updateStats(data.data);
            break;
        case 'openDeliveryMenu':
            if (tcDebug) console.log("[Tenny-Cargo] openDeliveryMenu mesajı işleniyor...");
            openDeliveryMenu(data.data);
            break;
        case 'closeDeliveryMenu':
            closeDeliveryMenu();
            break;
        case 'closeMenu':
            closeMenu();
            break;
    }
});

function openMenu(data) {
    // Önce tüm menüleri kapat
    document.getElementById('cargo-menu').style.display = 'none';
    document.getElementById('deliveryMenu').style.display = 'none';
    
    // Config'den ödeme değerini al
    if (data.paymentPerDelivery) {
        paymentPerDelivery = data.paymentPerDelivery;
    }
    
    // Etiketleri uygula (lokalizasyon)
    if (data.labels) {
        // labels'ı global sakla
        window.lastLabels = data.labels;
        if (data.labels.title) document.getElementById('titleText').textContent = data.labels.title;
        if (data.labels.subtitle) document.getElementById('subtitleText').textContent = data.labels.subtitle;
        if (data.labels.start_job) document.getElementById('startJobText').textContent = data.labels.start_job;
        if (data.labels.end_job) document.getElementById('endJobText').textContent = data.labels.end_job;
        if (data.labels.close) document.getElementById('closeBtn').textContent = data.labels.close;
        // status text dinamik olarak updateUI içinde set edilecek
    }

    // Menüyü hemen göster
    document.getElementById('cargo-menu').style.display = 'block';
    isWorking = data.isWorking || false;
    if (typeof data?.debug === 'boolean') tcDebug = data.debug;
    updateUI();
}

function startJob() {
    fetch(`https://${GetParentResourceName()}/startJob`, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({})
    });
    
    isWorking = true;
    updateUI();
}

function endJob() {
    fetch(`https://${GetParentResourceName()}/endJob`, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({})
    });
    
    isWorking = false;
    currentDelivery = null;
    updateUI();
}


function closeMenu() {
    document.getElementById('cargo-menu').style.display = 'none';
    document.getElementById('deliveryMenu').style.display = 'none';
    fetch(`https://${GetParentResourceName()}/closeMenu`, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({})
    });
}

function openDeliveryMenu(data) {
    if (tcDebug) console.log("[Tenny-Cargo] openDeliveryMenu çağrıldı", data);
    if (tcDebug) console.log("[Tenny-Cargo] Teslimat menüsü gösteriliyor...");
    document.getElementById('deliveryMenu').style.display = 'block';
    if (data.labels) {
        if (data.labels.delivery_title) document.getElementById('deliveryTitle').textContent = data.labels.delivery_title;
        if (data.labels.target) document.getElementById('targetLabel').textContent = data.labels.target;
        if (data.labels.desc_prefix) document.getElementById('descPrefix').textContent = data.labels.desc_prefix;
        if (data.labels.desc_suffix) document.getElementById('descSuffix').textContent = data.labels.desc_suffix;
        if (data.labels.deliver) document.getElementById('deliverText').textContent = data.labels.deliver;
    }
    document.getElementById('deliveryTarget').textContent = data.location.name;
    document.getElementById('packageNumber').textContent = data.packageNumber;
    
    // Hedef sayısını güncelle
    const targetNumberEl = document.getElementById('targetNumber');
    if (targetNumberEl) targetNumberEl.textContent = data.packageNumber;
    
    // Ödülü güncelle (teslimat sayısına göre)
    const reward = data.packageNumber * paymentPerDelivery; // Config'den gelen değer
    const currentRewardEl = document.getElementById('currentReward');
    if (currentRewardEl) currentRewardEl.textContent = '$' + reward;
    
    if (tcDebug) console.log("[Tenny-Cargo] Teslimat menüsü açıldı");
}

function closeDeliveryMenu() {
    document.getElementById('deliveryMenu').style.display = 'none';
}

function deliverPackage() {
    // Önce menüyü kapat
    closeDeliveryMenu();
    
    // Server'a teslimat mesajı gönder
    fetch(`https://${GetParentResourceName()}/deliverPackage`, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({})
    });
    
    // İstatistikleri güncelle (varsa)
    playerStats.totalDeliveries++;
    playerStats.totalEarnings += paymentPerDelivery; // Config'den gelen değer
    playerStats.lastDelivery = new Date().toLocaleTimeString();
    
    const totalDeliveriesEl = document.getElementById('totalDeliveries');
    const totalEarningsEl = document.getElementById('totalEarnings');
    if (totalDeliveriesEl) totalDeliveriesEl.textContent = playerStats.totalDeliveries;
    if (totalEarningsEl) totalEarningsEl.textContent = '$' + playerStats.totalEarnings;
    
    const targetNumberEl = document.getElementById('targetNumber');
    if (targetNumberEl) {
        const currentTarget = parseInt(targetNumberEl.textContent) || 0;
        targetNumberEl.textContent = currentTarget + 1;
        const currentRewardEl = document.getElementById('currentReward');
        if (currentRewardEl) currentRewardEl.textContent = '$' + ((currentTarget + 1) * paymentPerDelivery);
    }
    
    // Ana menüyü de kapat ve NUI focus'u kapat
    document.getElementById('cargo-menu').style.display = 'none';
    
    // NUI focus'u kapat
    fetch(`https://${GetParentResourceName()}/closeMenu`, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({})
    });
    
}

// cancelDelivery removed

function updateStatus(data) {
    isWorking = data.isWorking;
    updateUI();
}

function updateDelivery(data) {
    currentDelivery = data;
    updateDeliveryInfo();
}

function updateStats(data) {
    playerStats = data;
    updateStatsDisplay();
}

function updateUI() {
    if (isWorking) {
        statusText.textContent = (window.lastLabels && window.lastLabels.status_active) || 'İş Durumu: Aktif';
        startJobBtn.disabled = true;
        endJobBtn.disabled = false;
    } else {
        statusText.textContent = (window.lastLabels && window.lastLabels.status_ready) || 'İş Durumu: Hazır';
        startJobBtn.disabled = false;
        endJobBtn.disabled = true;
    }
}

function updateDeliveryInfo() {
    if (currentDelivery) {
        const targetLocationEl = document.getElementById('targetLocation');
        if (targetLocationEl) {
            targetLocationEl.textContent = `Koordinat: ${currentDelivery.x.toFixed(1)}, ${currentDelivery.y.toFixed(1)}`;
        }
        
        // Mesafe hesaplama (basit örnek)
        const distance = Math.random() * 2000 + 500; // 500-2500 arası rastgele
        const distanceEl = document.getElementById('distance');
        if (distanceEl) distanceEl.textContent = `${Math.round(distance)}m`;
    }
}


function showNotification(message, type) {
    // Basit bildirim sistemi
    const notification = document.createElement('div');
    notification.className = `notification ${type}`;
    notification.textContent = message;
    notification.style.cssText = `
        position: fixed;
        top: 20px;
        right: 20px;
        background: ${type === 'success' ? '#00ff88' : type === 'error' ? '#ff4444' : '#ffaa00'};
        color: ${type === 'success' ? '#000000' : '#ffffff'};
        padding: 15px 20px;
        border-radius: 8px;
        font-weight: bold;
        z-index: 1001;
        animation: slideInRight 0.3s ease-out;
    `;
    
    document.body.appendChild(notification);
    
    setTimeout(() => {
        notification.style.animation = 'slideOutRight 0.3s ease-in';
        setTimeout(() => {
            document.body.removeChild(notification);
        }, 300);
    }, 3000);
}

// CSS animasyonları
const style = document.createElement('style');
style.textContent = `
    @keyframes slideInRight {
        from {
            transform: translateX(100%);
            opacity: 0;
        }
        to {
            transform: translateX(0);
            opacity: 1;
        }
    }
    
    @keyframes slideOutRight {
        from {
            transform: translateX(0);
            opacity: 1;
        }
        to {
            transform: translateX(100%);
            opacity: 0;
        }
    }
`;
document.head.appendChild(style);

// Klavye kısayolları
document.addEventListener('keydown', function(event) {
    if (event.key === 'Escape') {
        closeMenu();
    }
});

// Sayfa yüklendiğinde
document.addEventListener('DOMContentLoaded', function() {
    // Menüyü gizle
    document.getElementById('cargo-menu').style.display = 'none';
    updateUI();
});
