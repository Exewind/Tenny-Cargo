local ESX = nil
local QBCore = nil
local FrameworkType = nil

-- Framework algılama
CreateThread(function()
    while true do
        if GetResourceState('es_extended') == 'started' then
            FrameworkType = 'esx'
            ESX = exports['es_extended']:getSharedObject()
            print('^2[Tenny-Cargo] ^7Framework algılandı: ^2ESX^7')
            break
        elseif GetResourceState('qb-core') == 'started' then
            FrameworkType = 'qb'
            QBCore = exports['qb-core']:GetCoreObject()
            print('^2[Tenny-Cargo] ^7Framework algılandı: ^2QB-Core^7')
            break
        end
        Wait(1000)
    end
    
    if not FrameworkType then
        print('^1[Tenny-Cargo] Framework bulunamadı!^0')
    end
end)

-- Paket ver (config'den miktar)
RegisterServerEvent('tenny-cargo:givePackages')
AddEventHandler('tenny-cargo:givePackages', function(amount)
    local src = source
    local xPlayer = nil
    
    if ESX then
        xPlayer = ESX.GetPlayerFromId(src)
        if xPlayer then
            xPlayer.addInventoryItem('kargopaketi', amount)
            -- Bildirim client'ta gönderiliyor, burada gereksiz
        end
    elseif QBCore then
        local Player = QBCore.Functions.GetPlayer(src)
        if Player then
            Player.Functions.AddItem('kargopaketi', amount)
            -- Bildirim client'ta gönderiliyor, burada gereksiz
        end
    end
end)

-- Paket kontrolü
RegisterServerEvent('tenny-cargo:checkPackage')
AddEventHandler('tenny-cargo:checkPackage', function()
    local src = source
    local hasPackage = false
    
    if ESX then
        local xPlayer = ESX.GetPlayerFromId(src)
        if xPlayer then
            local item = xPlayer.getInventoryItem('kargopaketi')
            hasPackage = item and item.count > 0
        end
    elseif QBCore then
        local Player = QBCore.Functions.GetPlayer(src)
        if Player then
            local item = Player.Functions.GetItemByName('kargopaketi')
            hasPackage = item and item.amount > 0
        end
    end
    
    -- Paket yoksa bildirim gönder
    if not hasPackage then
        local title = (Config.Locale == 'tr') and 'Hata' or 'Error'
        local message = (Config.Locale == 'tr') and 'Üzerinizde kargo paketi yok! Önce kargo alın.' or 'You have no cargo package! Get cargo first.'
        TriggerClientEvent('tenny-notify:Error', src, title, message, 4000)
    end
    
    TriggerClientEvent('tenny-cargo:packageCheckResult', src, hasPackage)
end)

-- Teslimat tamamlama (para yok, sadece paket sil)
RegisterServerEvent('tenny-cargo:deliveryComplete')
AddEventHandler('tenny-cargo:deliveryComplete', function(deliveryData)
    local src = source
    local xPlayer = nil
    local Player = nil
    local packageCount = 0
    
    if ESX then
        xPlayer = ESX.GetPlayerFromId(src)
        if xPlayer then
            -- Paket sil
            xPlayer.removeInventoryItem('kargopaketi', 1)
            
            -- Kalan paket sayısını kontrol et
            local item = xPlayer.getInventoryItem('kargopaketi')
            packageCount = item and item.count or 0
        end
    elseif QBCore then
        Player = QBCore.Functions.GetPlayer(src)
        if Player then
            -- Paket sil
            Player.Functions.RemoveItem('kargopaketi', 1)
            
            -- Kalan paket sayısını kontrol et
            local item = Player.Functions.GetItemByName('kargopaketi')
            packageCount = item and item.amount or 0
        end
    end
    
    -- Eğer hala paket varsa (1'den fazla) normal teslimat bildirimi
    if packageCount > 1 then
        local title = (Config.Locale == 'tr') and 'Kargo İşi' or 'Cargo Job'
        local message = (Config.Locale == 'tr') and 'Paket teslim edildi! Yeni teslim noktasına gidin.' or 'Package delivered! Go to next delivery point.'
        TriggerClientEvent('tenny-notify:Success', src, title, message, 4000)
    end
    -- Son paket ise bildirim yok (clearAllPackages'da toplam ödeme bildirimi gelecek)
end)

-- Paket sayısı kontrolü
RegisterServerEvent('tenny-cargo:checkRemainingPackages')
AddEventHandler('tenny-cargo:checkRemainingPackages', function()
    local src = source
    local packageCount = 0
    
    if ESX then
        local xPlayer = ESX.GetPlayerFromId(src)
        if xPlayer then
            local item = xPlayer.getInventoryItem('kargopaketi')
            packageCount = item and item.count or 0
        end
    elseif QBCore then
        local Player = QBCore.Functions.GetPlayer(src)
        if Player then
            local item = Player.Functions.GetItemByName('kargopaketi')
            packageCount = item and item.amount or 0
        end
    end
    
    -- Eğer paket kalmadıysa bonus para ver
    if packageCount == 0 then
        -- Config'den toplam para hesapla (koordinat sayısına göre)
        local totalPayment = Config.PaymentPerDelivery * #Config.DeliveryLocations
        
        if ESX then
            local xPlayer = ESX.GetPlayerFromId(src)
            if xPlayer then
                -- Toplam para ver (config'den hesaplanan)
                xPlayer.addMoney(totalPayment)
                
                -- Tenny-notify ile bildirim gönder (dil ayarına göre)
                local title = (Config.Locale == 'tr') and 'İş Tamamlandı' or 'Job Completed'
                local message = (Config.Locale == 'tr') and 'Tüm teslimatlar tamamlandı! Toplam ödeme: $' .. totalPayment or 'All deliveries completed! Total payment: $' .. totalPayment
                TriggerClientEvent('tenny-notify:Success', src, title, message, 5000)
            end
        elseif QBCore then
            local Player = QBCore.Functions.GetPlayer(src)
            if Player then
                -- Toplam para ver
                Player.Functions.AddMoney('cash', totalPayment)
                
                -- Tenny-notify ile bildirim gönder (dil ayarına göre)
                local title = (Config.Locale == 'tr') and 'İş Tamamlandı' or 'Job Completed'
                local message = (Config.Locale == 'tr') and 'Tüm teslimatlar tamamlandı! Toplam ödeme: $' .. totalPayment or 'All deliveries completed! Total payment: $' .. totalPayment
                TriggerClientEvent('tenny-notify:Success', src, title, message, 5000)
            end
        end
    end
    -- Hala paket varsa bildirim gönderme (gereksiz)
end)

-- Envanterdeki tüm kargo paketlerini sil (manuel iptal - para yok)
RegisterServerEvent('tenny-cargo:clearAllPackages')
AddEventHandler('tenny-cargo:clearAllPackages', function()
    local src = source
    
    if ESX then
        local xPlayer = ESX.GetPlayerFromId(src)
        if xPlayer then
            local item = xPlayer.getInventoryItem('kargopaketi')
            if item and item.count > 0 then
                xPlayer.removeInventoryItem('kargopaketi', item.count)
            end
            
            -- Bildirim - iş iptal edildi (para yok)
            local title = (Config.Locale == 'tr') and 'Kargo İşi İptal Edildi' or 'Cargo Job Cancelled'
            local message = (Config.Locale == 'tr') and 'İş iptal edildi.' or 'Job cancelled.'
            TriggerClientEvent('tenny-notify:Error', src, title, message, 4000)
        end
    elseif QBCore then
        local Player = QBCore.Functions.GetPlayer(src)
        if Player then
            local item = Player.Functions.GetItemByName('kargopaketi')
            if item and item.amount > 0 then
                Player.Functions.RemoveItem('kargopaketi', item.amount)
            end
            
            -- Bildirim - iş iptal edildi (para yok)
            local title = (Config.Locale == 'tr') and 'Kargo İşi İptal Edildi' or 'Cargo Job Cancelled'
            local message = (Config.Locale == 'tr') and 'İş iptal edildi.' or 'Job cancelled.'
            TriggerClientEvent('tenny-notify:Error', src, title, message, 4000)
        end
    end
end)

-- Tüm teslimatlar tamamlandı - ödeme yap
RegisterServerEvent('tenny-cargo:completeAllDeliveries')
AddEventHandler('tenny-cargo:completeAllDeliveries', function()
    local src = source
    local totalPayment = Config.PaymentPerDelivery * #Config.DeliveryLocations
    
    if ESX then
        local xPlayer = ESX.GetPlayerFromId(src)
        if xPlayer then
            local item = xPlayer.getInventoryItem('kargopaketi')
            if item and item.count > 0 then
                xPlayer.removeInventoryItem('kargopaketi', item.count)
            end
            
            -- Toplam ödeme yap
            xPlayer.addMoney(totalPayment)
            
            -- Bildirim - iş tamamlandı ve ödeme
            local title = (Config.Locale == 'tr') and 'İş Tamamlandı' or 'Job Completed'
            local message = (Config.Locale == 'tr') and 'Tüm teslimatlar tamamlandı! Toplam ödeme: $' .. totalPayment or 'All deliveries completed! Total payment: $' .. totalPayment
            TriggerClientEvent('tenny-notify:Success', src, title, message, 5000)
        end
    elseif QBCore then
        local Player = QBCore.Functions.GetPlayer(src)
        if Player then
            local item = Player.Functions.GetItemByName('kargopaketi')
            if item and item.amount > 0 then
                Player.Functions.RemoveItem('kargopaketi', item.amount)
            end
            
            -- Toplam ödeme yap
            Player.Functions.AddMoney('cash', totalPayment)
            
            -- Bildirim - iş tamamlandı ve ödeme
            local title = (Config.Locale == 'tr') and 'İş Tamamlandı' or 'Job Completed'
            local message = (Config.Locale == 'tr') and 'Tüm teslimatlar tamamlandı! Toplam ödeme: $' .. totalPayment or 'All deliveries completed! Total payment: $' .. totalPayment
            TriggerClientEvent('tenny-notify:Success', src, title, message, 5000)
        end
    end
end)