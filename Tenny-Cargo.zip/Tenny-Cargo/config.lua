Config = {}

-- Framework otomatik algılama
Config.Framework = 'auto' -- 'esx', 'qb', 'auto'

-- Dil ayarı
Config.Locale = 'tr' -- 'tr' veya 'en'

-- Debug ayarı
Config.Debug = false -- Debug mesajlarını göstermek için true yapın

-- NPC Ayarları
Config.NPCModel = 'a_m_m_business_01'
Config.DeliveryNPCModel = 'a_m_m_business_01'

-- İşe Başlama NPC'si (Sadece 1 adet)
Config.JobStartNPC = {
    vector4(78.8895, 112.5281, 81.1682, 163.7160) -- Los Santos Post Office
}

-- Kargo Teslim Noktaları (5 adet) - Her birinde NPC var
Config.DeliveryLocations = {
    {name = "1", npc = vector4(17.9662, -12.6672, 70.1161, 343.0002)},
    {name = "2", npc = vector4(-149.9449, 123.9829, 70.2253, 155.9947)},
    {name = "3", npc = vector4(-333.2972, 103.1237, 67.6174, 262.0938)},
    {name = "4", npc = vector4(1303.1055, -527.4016, 71.4605, 162.1413)},
    {name = "5", npc = vector4(1323.3455, -583.1962, 73.2463, 337.2995)},    
}

-- Araç Ayarları
Config.VehicleModel = 'boxville'
Config.VehicleSpawn = vector4(84.0409, 105.8925, 79.1686, 252.9563)

-- Blip Ayarları
Config.BlipSprite = 478
Config.BlipColor = 2
Config.BlipScale = 0.8

-- Ödül Ayarları
Config.PaymentPerDelivery = 5000  -- Her paket için ödeme
-- Toplam paket sayısı otomatik olarak koordinat sayısına göre ayarlanır

-- Menü Ayarları
Config.MenuKey = 'E'
Config.MenuDistance = 3.0

-- Paket Ayarları
Config.PackageModel = 'prop_cs_cardbox_01'
Config.PackageWeight = 1.0
