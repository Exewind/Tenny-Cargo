Config = {}

Config.Framework = 'auto'

Config.Locale = 'tr'

Config.Debug = false

Config.UseKeys = false

Config.NPCModel = 'a_m_m_business_01'
Config.DeliveryNPCModel = 'a_m_m_business_01'

Config.JobStartNPC = {
    vector4(78.8895, 112.5281, 81.1682, 163.7160)
}

Config.DeliveryLocations = {
    {name = "1", npc = vector4(17.9662, -12.6672, 70.1161, 343.0002)},
    {name = "2", npc = vector4(-333.2365, 101.2704, 71.2182, 274.5316)},
    {name = "3", npc = vector4(3.4313, 36.9017, 71.5305, 167.6731)},
    {name = "4", npc = vector4(-74.0901, 33.7404, 72.0768, 330.7697)},
    {name = "5", npc = vector4(-245.8423, 156.4557, 74.0545, 269.8833)},
    {name = "6", npc = vector4(-207.0352, 163.5403, 74.0532, 89.5884)},
    {name = "7", npc = vector4(-239.6953, 243.6843, 92.0432, 322.2737)},
    {name = "8", npc = vector4(-511.7421, 108.7180, 63.8005, 8.5505)},
    {name = "9", npc = vector4(-336.6451, 31.0788, 47.8590, 75.6645)},
    {name = "10", npc = vector4(-49.7980, -142.0215, 57.4657, 63.4301)},
}

Config.VehicleModel = 'boxville'
Config.VehicleSpawn = vector4(84.0409, 105.8925, 79.1686, 252.9563)

Config.BlipSprite = 478
Config.BlipColor = 2
Config.BlipScale = 0.8

Config.PaymentPerDelivery = 5000

Config.MenuKey = 'E'
Config.MenuDistance = 3.0

Config.PackageModel = 'prop_cs_cardbox_01'
Config.PackageWeight = 1.0
