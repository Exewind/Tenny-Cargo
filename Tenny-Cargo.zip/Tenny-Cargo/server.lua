local ESX = nil
local QBCore = nil

if GetResourceState('es_extended') == 'started' then
    ESX = exports['es_extended']:getSharedObject()
elseif GetResourceState('qb-core') == 'started' then
    QBCore = exports['qb-core']:GetCoreObject()
end

RegisterNetEvent('tenny-cargo:grantKeys', function(netId)
    local src = source
    if GetResourceState('qbx_vehiclekeys') ~= 'started' then return end
    if type(netId) ~= 'number' then return end
    local veh = NetworkGetEntityFromNetworkId(netId)
    if not veh or not DoesEntityExist(veh) then return end
    local ok = exports.qbx_vehiclekeys:GiveKeys(src, veh)
    if ok then
        local setLock = exports.qbx_vehiclekeys.SetLockState
        if setLock then setLock(veh, 'unlock') end
    end
end)

RegisterServerEvent('tenny-cargo:givePackages')
AddEventHandler('tenny-cargo:givePackages', function(amount)
    local src = source
    local xPlayer = nil
    
    if ESX then
        xPlayer = ESX.GetPlayerFromId(src)
        if xPlayer then
            xPlayer.addInventoryItem('kargopaketi', amount)
        end
    elseif QBCore then
        local Player = QBCore.Functions.GetPlayer(src)
        if Player then
            Player.Functions.AddItem('kargopaketi', amount)
        end
    end
end)

RegisterServerEvent('tenny-cargo:checkPackage')
AddEventHandler('tenny-cargo:checkPackage', function()
    local src = source
    local hasPackage = false
    
    if ESX then
        local xPlayer = ESX.GetPlayerFromId(src)
        if xPlayer then
            local item = xPlayer.getInventoryItem('kargopaketi')
            hasPackage = item and item.count > 0
        end
    elseif QBCore then
        local Player = QBCore.Functions.GetPlayer(src)
        if Player then
            local item = Player.Functions.GetItemByName('kargopaketi')
            hasPackage = item and item.amount > 0
        end
    end
    
    TriggerClientEvent('tenny-cargo:packageCheckResult', src, hasPackage)
end)

RegisterServerEvent('tenny-cargo:deliveryComplete')
AddEventHandler('tenny-cargo:deliveryComplete', function(deliveryData)
    local src = source
    local xPlayer = nil
    local Player = nil
    
    if ESX then
        xPlayer = ESX.GetPlayerFromId(src)
        if xPlayer then
            xPlayer.removeInventoryItem('kargopaketi', 1)
            
        end
    elseif QBCore then
        Player = QBCore.Functions.GetPlayer(src)
        if Player then
            Player.Functions.RemoveItem('kargopaketi', 1)
            
        end
    end
end)

RegisterServerEvent('tenny-cargo:checkRemainingPackages')
AddEventHandler('tenny-cargo:checkRemainingPackages', function()
    local src = source
    local packageCount = 0
    
    if ESX then
        local xPlayer = ESX.GetPlayerFromId(src)
        if xPlayer then
            local item = xPlayer.getInventoryItem('kargopaketi')
            packageCount = item and item.count or 0
        end
    elseif QBCore then
        local Player = QBCore.Functions.GetPlayer(src)
        if Player then
            local item = Player.Functions.GetItemByName('kargopaketi')
            packageCount = item and item.amount or 0
        end
    end
    
    if packageCount == 0 then
        local totalPayment = Config.PaymentPerDelivery * #Config.DeliveryLocations
        
        if ESX then
            local xPlayer = ESX.GetPlayerFromId(src)
            if xPlayer then
                xPlayer.addMoney(totalPayment)
                
                local prefix = (Locales and Config and Config.Locale and Locales[Config.Locale] and Locales[Config.Locale].notify_total_payment_prefix) or 'Toplam ödeme: $'
                TriggerClientEvent('esx:showNotification', src, ((Locales and Locales[Config.Locale] and Locales[Config.Locale].notify_all_done) or 'Tüm teslimatlar tamamlandı! İş bitti.') .. ' ' .. prefix .. totalPayment, 'success')
            end
        elseif QBCore then
            local Player = QBCore.Functions.GetPlayer(src)
            if Player then
                Player.Functions.AddMoney('cash', totalPayment)
                
                local prefix = (Locales and Config and Config.Locale and Locales[Config.Locale] and Locales[Config.Locale].notify_total_payment_prefix) or 'Toplam ödeme: $'
                TriggerClientEvent('QBCore:Notify', src, ((Locales and Locales[Config.Locale] and Locales[Config.Locale].notify_all_done) or 'Tüm teslimatlar tamamlandı! İş bitti.') .. ' ' .. prefix .. totalPayment, 'success')
            end
        end
    end
end)

RegisterServerEvent('tenny-cargo:clearAllPackages')
AddEventHandler('tenny-cargo:clearAllPackages', function()
    local src = source
    
    if ESX then
        local xPlayer = ESX.GetPlayerFromId(src)
        if xPlayer then
            local item = xPlayer.getInventoryItem('kargopaketi')
            if item and item.count > 0 then
                xPlayer.removeInventoryItem('kargopaketi', item.count)
            end
        end
    elseif QBCore then
        local Player = QBCore.Functions.GetPlayer(src)
        if Player then
            local item = Player.Functions.GetItemByName('kargopaketi')
            if item and item.amount > 0 then
                Player.Functions.RemoveItem('kargopaketi', item.amount)
            end
        end
    end
end)
