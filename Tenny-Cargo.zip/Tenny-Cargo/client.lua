local ESX = nil
local QBCore = nil
local PlayerData = {}
local currentJob = nil
local isWorking = false
local deliveryVehicle = nil
local currentDelivery = nil
local deliveryBlip = nil
local npcBlips = {}
local packageProp = nil
local completedDeliveries = {} -- Teslimat yapılan lokasyonları takip et
local deliveryCount = 0 -- Teslimat sayacı (1'den 25'e kadar)

-- Localization helper
local function _U(key)
    if Locales and Config and Config.Locale and Locales[Config.Locale] then
        return Locales[Config.Locale][key] or key
    end
    return key
end

-- Framework algılama
Citizen.CreateThread(function()
    if GetResourceState('es_extended') == 'started' then
        ESX = exports['es_extended']:getSharedObject()
        Config.Framework = 'esx'
    elseif GetResourceState('qb-core') == 'started' then
        QBCore = exports['qb-core']:GetCoreObject()
        Config.Framework = 'qb'
    end
    
    if ESX then
        while ESX.GetPlayerData().job == nil do
            Citizen.Wait(10)
        end
        PlayerData = ESX.GetPlayerData()
    elseif QBCore then
        PlayerData = QBCore.Functions.GetPlayerData()
    end
end)

-- Paket kontrolü sonucu
RegisterNetEvent('tenny-cargo:packageCheckResult')
AddEventHandler('tenny-cargo:packageCheckResult', function(hasPackage)
    if hasPackage then
        if Config.Debug then print("[Tenny-Cargo] Paket bulundu, teslimat menüsü açılıyor...") end
        OpenDeliveryMenu()
    else
        ShowNotification(_U('notify_no_package'), "error")
    end
end)

-- Sadece işe başlama NPC'sini oluştur
function CreateJobStartNPC()
    if Config.Debug then print("[Tenny-Cargo] İşe başlama NPC'si oluşturuluyor...") end
    
    -- İşe başlama NPC'si (1 adet)
    for i, location in ipairs(Config.JobStartNPC) do
        if Config.Debug then print("[Tenny-Cargo] NPC oluşturuluyor: " .. location.x .. ", " .. location.y .. ", " .. location.z) end
        
        -- NPC modelini yükle
        local npcHash = GetHashKey(Config.NPCModel)
        if Config.Debug then print("[Tenny-Cargo] NPC modeli yükleniyor: " .. Config.NPCModel .. " (Hash: " .. npcHash .. ")") end
        RequestModel(npcHash)
        while not HasModelLoaded(npcHash) do
            Citizen.Wait(100)
        end
        if Config.Debug then print("[Tenny-Cargo] NPC modeli yüklendi!") end
        
        local npc = CreatePed(4, npcHash, location.x, location.y, location.z - 1, location.w, false, true)
        FreezeEntityPosition(npc, true)
        SetEntityInvincible(npc, true)
        SetBlockingOfNonTemporaryEvents(npc, true)
        
        -- Modeli serbest bırak
        SetModelAsNoLongerNeeded(npcHash)
        
        if Config.Debug then print("[Tenny-Cargo] İşe başlama NPC'si oluşturuldu: " .. npc) end
        
        -- Blip oluştur
        local blip = AddBlipForCoord(location.x, location.y, location.z)
        SetBlipSprite(blip, Config.BlipSprite)
        SetBlipDisplay(blip, 4)
        SetBlipScale(blip, Config.BlipScale)
        SetBlipColour(blip, Config.BlipColor)
        SetBlipAsShortRange(blip, true)
        BeginTextCommandSetBlipName("STRING")
        AddTextComponentString(_U('blip_cargo_center'))
        EndTextCommandSetBlipName(blip)
        
        table.insert(npcBlips, blip)
    end
end

-- Teslimat blip'lerini oluştur (sadece iş başladığında)
function CreateDeliveryBlips()
    if Config.Debug then print("[Tenny-Cargo] Teslimat blip'leri oluşturuluyor...") end
    
    -- Teslimat blip'leri (koordinat sayısına göre)
    for i, location in ipairs(Config.DeliveryLocations) do
        -- Blip oluştur
        local blip = AddBlipForCoord(location.npc.x, location.npc.y, location.npc.z)
        SetBlipSprite(blip, 478)
        SetBlipDisplay(blip, 4)
        SetBlipScale(blip, 0.6)
        SetBlipColour(blip, 3)
        SetBlipAsShortRange(blip, true)
        BeginTextCommandSetBlipName("STRING")
        AddTextComponentString(_U('blip_delivery_point'))
        EndTextCommandSetBlipName(blip)
        
        table.insert(npcBlips, blip)
        if Config.Debug then print("[Tenny-Cargo] Teslimat blip'i oluşturuldu: " .. location.name) end
    end
end

-- Menü açma
function OpenCargoMenu()
    if Config.Debug then print("[Tenny-Cargo] OpenCargoMenu çağrıldı") end
    
    -- NUI Focus'u ayarla
    if Config.Debug then print("[Tenny-Cargo] NUI Focus ayarlanıyor...") end
    SetNuiFocus(true, true)
    
    -- Menüyü aç
    if Config.Debug then print("[Tenny-Cargo] Menü mesajı gönderiliyor...") end
    SendNUIMessage({
        type = "openMenu",
        data = {
            debug = Config.Debug,
            locations = Config.DeliveryLocations,
            currentJob = currentJob,
            isWorking = isWorking,
            paymentPerDelivery = Config.PaymentPerDelivery,
            labels = {
                title = _U('nui_title'),
                subtitle = _U('nui_subtitle'),
                status_ready = _U('nui_status_ready'),
                status_active = _U('nui_status_active'),
                start_job = _U('nui_start_job'),
                end_job = _U('nui_end_job'),
                close = _U('nui_close')
            }
        }
    })
    
    if Config.Debug then print("[Tenny-Cargo] Menü açma işlemi tamamlandı") end
end

-- İş başlatma
function StartCargoJob()
    if isWorking then
        ShowNotification(_U('notify_already_on_job'), "error")
        return
    end
    
    -- Araç spawn
    local spawnCoords = Config.VehicleSpawn
    if Config.Debug then print("[Tenny-Cargo] Araç spawn ediliyor: " .. Config.VehicleModel .. " koordinat: " .. spawnCoords.x .. ", " .. spawnCoords.y .. ", " .. spawnCoords.z) end
    
    -- Araç modelini kontrol et
    local vehicleHash = GetHashKey(Config.VehicleModel)
    if not IsModelValid(vehicleHash) then
        ShowNotification(_U('notify_invalid_vehicle') .. Config.VehicleModel, "error")
        return
    end
    
    -- Model yüklenene kadar bekle
    RequestModel(vehicleHash)
    while not HasModelLoaded(vehicleHash) do
        Citizen.Wait(100)
    end
    
    local vehicle = CreateVehicle(vehicleHash, spawnCoords.x, spawnCoords.y, spawnCoords.z, spawnCoords.w, true, false)
    
    -- Araç spawn kontrolü
    if not DoesEntityExist(vehicle) then
        ShowNotification(_U('notify_vehicle_spawn_fail'), "error")
        return
    end
    
    SetEntityAsMissionEntity(vehicle, true, true)
    SetVehicleOnGroundProperly(vehicle)
    SetPedIntoVehicle(PlayerPedId(), vehicle, -1)

    -- Anahtar ve sürüş ayarları (QBX qbx_vehiclekeys ile uyumlu)
    -- Kapıları aç, motoru çalıştır ve sürülebilir yap
    SetVehicleDoorsLocked(vehicle, 1)
    SetVehicleEngineOn(vehicle, true, true, false)
    SetVehicleUndriveable(vehicle, false)
    FreezeEntityPosition(vehicle, false)

    -- Opsiyonel anahtar entegrasyonu
    if Config.UseKeys then
        local plate = GetVehicleNumberPlateText(vehicle)
        if plate then plate = plate:gsub('%s+', '') end
        if GetResourceState('qbx_vehiclekeys') == 'started' then
            -- Qbox keys (server tarafı güvenli ise oradan da verebilirsin)
            TriggerServerEvent('qbx_vehiclekeys:server:tookKeys', VehToNet(vehicle))
        elseif GetResourceState('qb-vehiclekeys') == 'started' then
            -- Eski qb-vehiclekeys
            TriggerEvent('vehiclekeys:client:SetOwner', plate)
        elseif GetResourceState('wasabi_carlock') == 'started' then
            TriggerEvent('wasabi_carlock:giveKeys', plate)
        end
    end

    deliveryVehicle = vehicle
    isWorking = true
    
    -- Modeli serbest bırak
    SetModelAsNoLongerNeeded(vehicleHash)
    
    if Config.Debug then print("[Tenny-Cargo] Araç başarıyla spawn edildi!") end
    
    -- İlk teslimat noktası (1. paket)
    deliveryCount = 1
    currentDelivery = Config.DeliveryLocations[1]
    
    -- Blip oluştur
    deliveryBlip = AddBlipForCoord(currentDelivery.npc.x, currentDelivery.npc.y, currentDelivery.npc.z)
    SetBlipSprite(deliveryBlip, 1)
    SetBlipDisplay(deliveryBlip, 4)
    SetBlipScale(deliveryBlip, 1.0)
    SetBlipColour(deliveryBlip, 2)
    SetBlipRoute(deliveryBlip, true)
    BeginTextCommandSetBlipName("STRING")
    AddTextComponentString(_U('blip_cargo_delivery_point'))
    EndTextCommandSetBlipName(deliveryBlip)
    
    -- Teslimat blip'lerini oluştur
    CreateDeliveryBlips()
    
    -- Koordinat sayısına göre paket sayısını hesapla
    local totalPackages = #Config.DeliveryLocations
    TriggerServerEvent('tenny-cargo:givePackages', totalPackages)
    
    ShowNotification(_U('notify_job_started') .. totalPackages .. _U('notify_job_started_suffix'), "success")
    
    -- Menüyü otomatik kapat
    SetNuiFocus(false, false)
    SendNUIMessage({
        type = "closeMenu"
    })
end

-- Teslim kontrolü (Bu fonksiyon artık kullanılmıyor - StartDeliveryConversation ile değiştirildi)
function CheckDelivery()
    -- Bu fonksiyon artık kullanılmıyor
    return
end

-- İş bitirme
function EndCargoJob()
    if deliveryVehicle then
        DeleteEntity(deliveryVehicle)
        deliveryVehicle = nil
    end
    
    if deliveryBlip then
        RemoveBlip(deliveryBlip)
        deliveryBlip = nil
    end
    
    -- Teslimat NPC'lerini ve blipleri temizle
    for i, blip in ipairs(npcBlips) do
        if blip and DoesBlipExist(blip) then
            RemoveBlip(blip)
        end
    end
    npcBlips = {}
    
    -- Paket prop'unu temizle
    RemovePackageProp()
    
    isWorking = false
    currentDelivery = nil
    deliveryCount = 0
    completedDeliveries = {}
    
    -- Envanterdeki tüm kargo paketlerini sil
    TriggerServerEvent('tenny-cargo:clearAllPackages')
    
    ShowNotification(_U('notify_job_ended'), "info")
end

-- Bildirim fonksiyonu
function ShowNotification(message, type)
    if Config.Framework == 'esx' then
        ESX.ShowNotification(message)
    elseif Config.Framework == 'qb' then
        QBCore.Functions.Notify(message, type)
    else
        -- Fallback
        SetNotificationTextEntry("STRING")
        AddTextComponentString(message)
        DrawNotification(0, 1)
    end
end

-- Event handlers
RegisterNetEvent('tenny-cargo:deliveryComplete')
AddEventHandler('tenny-cargo:deliveryComplete', function()
    ShowNotification("Paket başarıyla teslim edildi! +$" .. Config.PaymentPerDelivery, "success")
end)

RegisterNetEvent('tenny-cargo:openMenu')
AddEventHandler('tenny-cargo:openMenu', function()
    OpenCargoMenu()
end)

-- NUI Callbacks
RegisterNUICallback('startJob', function(data, cb)
    StartCargoJob()
    cb('ok')
end)

RegisterNUICallback('endJob', function(data, cb)
    EndCargoJob()
    cb('ok')
end)

RegisterNUICallback('closeMenu', function(data, cb)
    SetNuiFocus(false, false)
    cb('ok')
end)

RegisterNUICallback('deliverPackage', function(data, cb)
    CompleteDelivery()
    cb('ok')
end)

RegisterNUICallback('closeDeliveryMenu', function(data, cb)
    SetNuiFocus(false, false)
    SendNUIMessage({
        type = "closeDeliveryMenu"
    })
    cb('ok')
end)

-- Ana thread
Citizen.CreateThread(function()
    CreateJobStartNPC()
    
    while true do
        Citizen.Wait(0)
        
        local playerPed = PlayerPedId()
        local playerCoords = GetEntityCoords(playerPed)
        
        -- ESC tuşu ile menü kapatma
        if IsControlJustPressed(0, 322) then -- ESC tuşu
            SetNuiFocus(false, false)
            SendNUIMessage({
                type = "closeMenu"
            })
        end
        
        -- İşe başlama NPC etkileşimi
        for i, location in ipairs(Config.JobStartNPC) do
            local distance = #(playerCoords - vector3(location.x, location.y, location.z))
            
            if distance < Config.MenuDistance then
                DrawText3D(location.x, location.y, location.z, _U('hint_open_menu'))
                
                if IsControlJustPressed(0, 38) then -- E tuşu
                    if Config.Debug then print("[Tenny-Cargo] E tuşuna basıldı, menü açılıyor...") end
                    OpenCargoMenu()
                end
            end
        end
        
        -- Teslimat NPC etkileşimi (sadece iş aktifken)
        if isWorking and currentDelivery then
            local distance = #(playerCoords - vector3(currentDelivery.npc.x, currentDelivery.npc.y, currentDelivery.npc.z))
            
            if distance < Config.MenuDistance then
                DrawText3D(currentDelivery.npc.x, currentDelivery.npc.y, currentDelivery.npc.z, _U('hint_deliver_package'))
                
                if IsControlJustPressed(0, 38) then -- E tuşu
                    -- Konuşma sistemi
                    StartDeliveryConversation()
                end
            end
        end
        
        -- Teslim kontrolü artık StartDeliveryConversation ile yapılıyor
    end
end)

-- Konuşma sistemi
function StartDeliveryConversation()
    if Config.Debug then print("[Tenny-Cargo] StartDeliveryConversation çağrıldı") end
    local playerPed = PlayerPedId()
    
    -- Araç kontrolü - sadece araçtan çıkıldığında teslim yapılabilir
    if IsPedInVehicle(playerPed, deliveryVehicle, false) then
        ShowNotification(_U('notify_exit_vehicle'), "error")
        return
    end
    
    -- Sıralı teslimat sistemi - aynı lokasyona tekrar gitme kontrolü gereksiz
    
    -- Envanter kontrolü - paket var mı?
    TriggerServerEvent('tenny-cargo:checkPackage')
end

-- Teslimat menüsü
function OpenDeliveryMenu()
    if Config.Debug then print("[Tenny-Cargo] OpenDeliveryMenu çağrıldı") end
    if Config.Debug then print("[Tenny-Cargo] NUI Focus ayarlanıyor...") end
    SetNuiFocus(true, true)
    
    if Config.Debug then print("[Tenny-Cargo] Teslimat menü mesajı gönderiliyor...") end
    SendNUIMessage({
        type = "openDeliveryMenu",
        data = {
            debug = Config.Debug,
            location = currentDelivery,
            packageNumber = deliveryCount,
            hasPackage = packageProp and DoesEntityExist(packageProp),
            labels = {
                delivery_title = _U('nui_delivery_title'),
                target = _U('nui_target'),
                desc_prefix = _U('nui_desc_prefix'),
                desc_suffix = _U('nui_desc_suffix'),
                deliver = _U('nui_deliver'),
                cancel = _U('nui_cancel')
            }
        }
    })
    
    if Config.Debug then print("[Tenny-Cargo] Teslimat menü açma işlemi tamamlandı") end
end

-- Teslim tamamlama
function CompleteDelivery()
    local playerPed = PlayerPedId()
    
    -- NUI focus'u kapat
    SetNuiFocus(false, false)
    
    -- Paket sil ve para ver
    TriggerServerEvent('tenny-cargo:deliveryComplete', currentDelivery)
    
    -- Paket sayısını kontrol et (tüm paketler teslim edildi mi?)
    TriggerServerEvent('tenny-cargo:checkRemainingPackages')
    
    -- Teslimat sayacını artır
    deliveryCount = deliveryCount + 1
    
    -- Blip temizle
    RemoveBlip(deliveryBlip)
    deliveryBlip = nil
    
    -- Sıradaki teslimat noktası (eğer 25'ten azsa)
    if deliveryCount <= #Config.DeliveryLocations then
        currentDelivery = Config.DeliveryLocations[deliveryCount]
    else
        -- Tüm teslimatlar tamamlandı
        ShowNotification(_U('notify_all_done'), "success")
        EndCargoJob()
        return
    end
    
    -- Yeni blip oluştur
    deliveryBlip = AddBlipForCoord(currentDelivery.npc.x, currentDelivery.npc.y, currentDelivery.npc.z)
    SetBlipSprite(deliveryBlip, 1)
    SetBlipDisplay(deliveryBlip, 4)
    SetBlipScale(deliveryBlip, 1.0)
    SetBlipColour(deliveryBlip, 2)
    SetBlipRoute(deliveryBlip, true)
    BeginTextCommandSetBlipName("STRING")
    AddTextComponentString(_U('blip_cargo_delivery_point'))
    EndTextCommandSetBlipName(deliveryBlip)
    
    ShowNotification(_U('notify_next_point'), "success")
end

-- Paket prop'u oluştur
function CreatePackageProp()
    local playerPed = PlayerPedId()
    local playerCoords = GetEntityCoords(playerPed)
    
    -- Paket modelini yükle
    local packageHash = GetHashKey(Config.PackageModel)
    RequestModel(packageHash)
    while not HasModelLoaded(packageHash) do
        Citizen.Wait(100)
    end
    
    -- Paket prop'u oluştur
    packageProp = CreateObject(packageHash, playerCoords.x, playerCoords.y, playerCoords.z, true, true, true)
    
    -- Paketi oyuncunun eline ver (daha doğal pozisyon)
    AttachEntityToEntity(packageProp, playerPed, GetPedBoneIndex(playerPed, 57005), 0.15, 0.05, 0.0, 0.0, 0.0, 0.0, true, true, false, true, 1, true)
    
    -- Modeli serbest bırak
    SetModelAsNoLongerNeeded(packageHash)
    
    if Config.Debug then print("[Tenny-Cargo] Paket prop'u oluşturuldu!") end
end

-- Paket prop'unu temizle
function RemovePackageProp()
    if packageProp and DoesEntityExist(packageProp) then
        DeleteEntity(packageProp)
        packageProp = nil
        if Config.Debug then print("[Tenny-Cargo] Paket prop'u temizlendi!") end
    end
end

-- 3D text çizme
function DrawText3D(x, y, z, text)
    local onScreen, _x, _y = World3dToScreen2d(x, y, z)
    local px, py, pz = table.unpack(GetGameplayCamCoords())
    
    SetTextScale(0.35, 0.35)
    SetTextFont(4)
    SetTextProportional(1)
    SetTextColour(255, 255, 255, 215)
    SetTextEntry("STRING")
    SetTextCentre(1)
    AddTextComponentString(text)
    DrawText(_x, _y)
    local factor = (string.len(text)) / 370
    DrawRect(_x, _y + 0.0125, 0.015 + factor, 0.03, 0, 0, 0, 75)
end
