fx_version 'cerulean'
game 'gta5'

author 'Tenny-Cargo'
description 'ESX/QB-Core Uyumlu Kargo Scripti'
version '1.0.0'

dependencies {
    'tenny-notify'
}

shared_scripts {
    'config.lua',
    'locales/tr.lua',
    'locales/en.lua'
}

client_scripts {
    'client/client.lua'
}

server_scripts {
    'server/server.lua'
}

ui_page 'html/index.html'

files {
    'html/index.html',
    'html/style.css',
    'html/script.js',
    'html/images/*.png'
}

lua54 'yes'
