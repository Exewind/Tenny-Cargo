# 🚚 Tenny-Cargo

<div align="center">

![Version](https://img.shields.io/badge/version-1.0.0-blue.svg)
![Framework](https://img.shields.io/badge/framework-ESX%20%7C%20QB--Core-green.svg)
![License](https://img.shields.io/badge/license-Custom-red.svg)
![Language](https://img.shields.io/badge/language-Lua-orange.svg)

**Modern FiveM Kargo Teslimat Sistemi**

*ESX/QB-Core Uyumlu • Çoklu Dil Desteği • Modern NUI Arayüzü*

[📖 Dokümantasyon](#-özellikler) • [🛠️ Kurulum](#️-kurulum) • [⚙️ Konfigürasyon](#️-konfigürasyon) • [🎮 Kullanım](#-kullanım)

</div>

---

## 📋 İçindekiler

- [✨ Özellikler](#-özellikler)
- [🛠️ Kurulum](#️-kurulum)
- [⚙️ Konfigürasyon](#️-konfigürasyon)
- [🎮 Kullanım](#-kullanım)
- [🌍 Dil Desteği](#-dil-desteği)
- [🔧 Gelişmiş Özellikler](#-gelişmiş-özellikler)
- [🐛 Sorun Giderme](#-sorun-giderme)
- [📋 Changelog](#-changelog)
- [📄 Lisans](#-lisans)

---

## ✨ Özellikler

### 🎯 **Ana Özellikler**

| Özellik | Açıklama |
|---------|----------|
| 🔄 **Framework Uyumluluğu** | ESX & QB-Core otomatik algılama |
| 🎨 **Modern NUI** | Responsive ve kullanıcı dostu tasarım |
| 🌍 **Çoklu Dil** | Türkçe ve İngilizce dil seçenekleri |
| 🚛 **Gerçekçi Deneyim** | Paket taşıma, araç kullanma, teslimat |
| 🗺️ **GPS Navigasyon** | Otomatik rota çizimi ve yönlendirme |
| 📍 **Özelleştirilebilir** | 10+ farklı teslimat noktası |
| 💰 **Ödül Sistemi** | Tüm teslimatlar bitince toplam ödül |

### 🚛 **Kargo Sistemi**

- **🏢 İşe Başlama** - Kargo merkezinden işe başlama
- **🚗 Araç Spawn** - Otomatik kargo aracı verme
- **📦 Paket Yönetimi** - Envanter sistemi ile paket kontrolü
- **📍 Sıralı Teslimat** - Belirli sırayla teslimat yapma
- **🗺️ GPS Yönlendirme** - Her teslimat için otomatik rota
- **💰 Ödül Sistemi** - Tüm teslimatlar bitince toplam ödül kazanma

### 🎮 **Kullanıcı Arayüzü**

- **🎨 Modern Tasarım** - Emoji ve ikon destekli arayüz
- **📱 Responsive Menü** - Tüm ekran boyutlarına uyumlu
- **⚡ Gerçek Zamanlı** - İş durumu takibi
- **🖱️ Kolay Kullanım** - Tek tıkla işlem yapma

---

## 🛠️ Kurulum

### 📋 **Gereksinimler**

- ✅ **ESX** veya **QB-Core** framework
- ✅ **FiveM Server** (v1.0+)
- ✅ **MySQL** veritabanı (opsiyonel)

### 📥 **Kurulum Adımları**

#### 1️⃣ **Dosyaları İndirin**
```bash
git clone https://github.com/Exewind/Tenny-Cargo.git
```

#### 2️⃣ **Sunucuya Yükleyin**
1. `tenny-cargo` klasörünü `resources` dizinine kopyalayın
2. `server.cfg` dosyanıza ekleyin:
```cfg
ensure tenny-cargo
```

#### 3️⃣ **Veritabanı Ayarları** *(Opsiyonel)*
- Script otomatik olarak çalışır
- Ek veritabanı tablosu gerektirmez

#### 4️⃣ **Sunucuyu Yeniden Başlatın**
```bash
restart tenny-cargo
```

---

## ⚙️ Konfigürasyon

### 🔧 **Temel Ayarlar** (`config.lua`)

```lua
-- Framework ayarı
Config.Framework = 'auto' -- 'esx', 'qb', 'auto'

-- Dil ayarı
Config.Locale = 'tr' -- 'tr' veya 'en'

-- Debug modu
Config.Debug = false

-- Anahtar sistemi
Config.UseKeys = false -- Araç anahtarı verme
```

### 👥 **NPC Ayarları**

```lua
-- NPC modelleri
Config.NPCModel = 'a_m_m_business_01'
Config.DeliveryNPCModel = 'a_m_m_business_01'

-- İşe başlama NPC'si
Config.JobStartNPC = {
    vector4(78.8895, 112.5281, 81.1682, 163.7160) -- Los Santos Post Office
}
```

### 📍 **Teslimat Noktaları**

```lua
Config.DeliveryLocations = {
    {name = "1", npc = vector4(17.9662, -12.6672, 70.1161, 343.0002)},
    {name = "2", npc = vector4(-333.2365, 101.2704, 71.2182, 274.5316)},
    {name = "3", npc = vector4(3.4313, 36.9017, 71.5305, 167.6731)},
    -- Daha fazla konum ekleyebilirsiniz...
}
```

### 🚗 **Araç Ayarları**

```lua
-- Kargo aracı
Config.VehicleModel = 'boxville'
Config.VehicleSpawn = vector4(84.0409, 105.8925, 79.1686, 252.9563)

-- Blip ayarları
Config.BlipSprite = 478
Config.BlipColor = 2
Config.BlipScale = 0.8
```

### 💰 **Ödül Sistemi**

```lua
-- Her teslimat için ödeme (toplam hesaplama için)
Config.PaymentPerDelivery = 5000

-- Toplam ödül = PaymentPerDelivery × Teslimat Noktası Sayısı
-- Örnek: 5000 × 10 = 50,000$ (10 teslimat noktası için)

-- Paket ayarları
Config.PackageModel = 'prop_cs_cardbox_01'
Config.PackageWeight = 1.0
```

---

## 🎮 Kullanım

### 👤 **Oyuncu İçin**

| Adım | Açıklama |
|------|----------|
| 1️⃣ | **Kargo Merkezine Gidin** - Haritada "Kargo Merkezi" blip'ini bulun |
| 2️⃣ | **NPC ile Etkileşim** - [E] tuşuna basarak menüyü açın |
| 3️⃣ | **İşe Başlayın** - "İşe Başla" butonuna tıklayın |
| 4️⃣ | **Aracı Alın** - Spawn edilen kargo aracına binin |
| 5️⃣ | **Teslimat Yapın** - GPS'e göre teslimat noktalarına gidin |
| 6️⃣ | **Paketi Teslim Edin** - [E] tuşu ile paketi teslim edin |
| 7️⃣ | **Tüm Teslimatları Tamamlayın** - Tüm paketleri teslim edin |
| 8️⃣ | **Toplam Ödül Kazanın** - Tüm teslimatlar bitince toplam para kazanın |

### 👨‍💼 **Admin İçin**

- **📍 Konum Ekleme**: `config.lua` dosyasından yeni teslimat noktaları ekleyebilirsiniz
- **💰 Ödül Ayarlama**: `Config.PaymentPerDelivery` değerini değiştirin
- **🐛 Debug Modu**: `Config.Debug = true` yaparak hata ayıklama yapabilirsiniz

---

## 🌍 Dil Desteği

### 🌐 **Mevcut Diller**

| Dil | Dosya | Durum |
|-----|-------|-------|
| 🇹🇷 **Türkçe** | `tr.lua` | ✅ Varsayılan |
| 🇺🇸 **İngilizce** | `en.lua` | ✅ Tam destek |

### ➕ **Yeni Dil Ekleme**

1. `locales/` klasörüne yeni dil dosyası ekleyin (örn: `de.lua`)
2. `config.lua` dosyasında `Config.Locale = 'de'` yapın
3. Dil dosyasını aşağıdaki format ile doldurun:

```lua
Locales = Locales or {}
Locales['de'] = {
    blip_cargo_center = "Frachtzentrum",
    blip_delivery_point = "Lieferpunkt",
    hint_open_menu = "[E] Frachtmenü",
    -- Diğer çeviriler...
}
```

---

## 🔧 Gelişmiş Özellikler

### 🔑 **Anahtar Sistemi Entegrasyonu**

```lua
-- Desteklenen anahtar sistemleri
Config.UseKeys = true -- Aktif etmek için

-- Desteklenen sistemler:
-- ✅ qbx_vehiclekeys
-- ✅ qb-vehiclekeys  
-- ✅ wasabi_carlock
```

### 🚗 **Özel Araç Modelleri**

```lua
-- Farklı kargo araçları kullanabilirsiniz
Config.VehicleModel = 'mule'      -- Küçük kargo aracı
Config.VehicleModel = 'boxville'  -- Orta boy kargo aracı
Config.VehicleModel = 'pounder'   -- Büyük kargo aracı
```

### 🗺️ **Blip Özelleştirme**

```lua
-- Farklı blip türleri
Config.BlipSprite = 478 -- Kargo ikonu
Config.BlipColor = 2    -- Yeşil renk
Config.BlipScale = 0.8  -- Boyut
```

---

## 🐛 Sorun Giderme

### ❓ **Yaygın Sorunlar**

| Sorun | Çözüm |
|-------|-------|
| **Script Yüklenmiyor** | `fxmanifest.lua` dosyasının doğru olduğundan emin olun |
| **NPC Görünmüyor** | `Config.NPCModel` değerinin geçerli olduğundan emin olun |
| **Araç Spawn Olmuyor** | `Config.VehicleModel` değerinin geçerli olduğundan emin olun |
| **Para Verilmiyor** | Framework entegrasyonunu kontrol edin |

### 🔍 **Debug Modu**

```lua
Config.Debug = true -- Debug mesajlarını görmek için
```

---

## 📋 Changelog

### 🆕 **v1.0.0** - *İlk Sürüm*

- ✅ İlk sürüm yayınlandı
- ✅ ESX/QB-Core uyumluluğu
- ✅ Modern NUI arayüzü
- ✅ Çoklu dil desteği
- ✅ GPS navigasyon sistemi
- ✅ Özelleştirilebilir konumlar

---

---

## 📄 Lisans

Bu yazılım ücretsizdir ancak aşağıdaki kısıtlamalar geçerlidir:

❌ **Değiştirilemez**  
❌ **Satılamaz**  
❌ **Türev çalışma yapılamaz**  
❌ **Ticari kullanım yasak**  
✅ **Sadece orijinal haliyle ücretsiz kullanılabilir**

Bu kısıtlamalara uymayan kullanım yasaktır.

---

**EN**

This software is free to use, but the following restrictions apply:

❌ **May not be modified**  
❌ **May not be sold**  
❌ **Derivative works are not allowed**  
❌ **Commercial use is strictly prohibited**  
✅ **May only be used in its original form, free of charge**

Any use that violates these restrictions is strictly prohibited.

---

## 👨‍💻 Geliştirici

**Tenny-Cargo** - Modern FiveM kargo sistemi

## 📞 Destek

- **🐛 GitHub Issues**: Hata bildirimi ve özellik istekleri
- **💬 Discord**: https://discord.gg/ZBuNKA6ZxQ

---

<div align="center">

### ⭐ Beğendiyseniz Yıldız Vermeyi Unutmayın!

Bu script FiveM topluluğu için ücretsiz olarak geliştirilmiştir.  
Beğendiyseniz GitHub'da yıldız vererek bize destek olabilirsiniz! 🚀

</div>